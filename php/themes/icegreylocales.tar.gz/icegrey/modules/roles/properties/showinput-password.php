<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Type password again:'] = 'Bitte Kennwort nochmals eingeben:';
$xarML_PHPBackend_entries['Type again:'] = 'Bitte nochmal eingeben:';
?>