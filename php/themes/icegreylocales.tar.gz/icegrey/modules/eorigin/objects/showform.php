<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Enter the name of your document'] = 'Geben Sie den Name des Dokuments ein';
$xarML_PHPBackend_entries['Personal Information'] = 'Persönliche Daten';
$xarML_PHPBackend_entries['Enter your personal information in the fields below. All entries are required.'] = 'Geben Sie Ihre persönlichen Daten in den untenstehenden Feldern. Alle Felder sind obligatorisch.';
$xarML_PHPBackend_entries['Birth Date'] = 'Geburtsdatum';
$xarML_PHPBackend_entries['Nationality'] = 'Staatsangehörigkeit';
$xarML_PHPBackend_entries['Passport ID'] = 'Reisepass-Nummer';
$xarML_PHPBackend_entries['Click on the button below to upload an image file from your computer. Please upload only scans of your passport or equivalent identity document.'] = 'Klicken Sie unten, um eine Datei von Ihrem Computer zu laden. Bitte laden Sie nur Abbilder Ihres Reisepasses oder eines äquivalenten, amtlichen Ausweises.';
$xarML_PHPBackend_entries['The allowed file types are jpg, jpeg, png, gif and pdf.'] = 'Die unterstützten Dateitypen sind jpg, jpeg, png, gif und pdf.';
$xarML_PHPBackend_entries['Document Pages'] = 'Dokumentenseiten';
$xarML_PHPBackend_entries['Click on the button below to upload up to 5 image files from your computer. These are the documents that will be notarized.'] = 'Klicken Sie unten um maximal 5 Abbilder von Ihrem Computer zu laden. Diese Dokumente werden notariell Beglaubigt.';
$xarML_PHPBackend_entries['Page Size'] = 'Seiten Grösse';
$xarML_PHPBackend_entries['Choose a page size for your document.'] = 'Wählen Sie eine Seitengrösse für Ihr Dokument';
$xarML_PHPBackend_entries['Terms and Conditions'] = 'Nutzungsbedingungen und Konditionen';
$xarML_PHPBackend_entries['Click on the button below to read our terms and conditions. Once you have read them click on the checkbox.'] = 'Klicken Sie unten, um die Nutzungsbedingungen und Konditionen zu lesen. Klicken Sie bitte auf die Checkbox, wenn Sie diese gelesen haben.';
$xarML_PHPBackend_entries[' 
I agree with the terms and conditions.'] = 'Ich akzeptiere die Nutzungsbedingungen und Konditionen.';
?>