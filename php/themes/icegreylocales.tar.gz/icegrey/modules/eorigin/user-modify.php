<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['"active"'] = '"aktiv"';
$xarML_PHPBackend_entries['Application'] = 'Applikation';
$xarML_PHPBackend_entries['Cover Page'] = 'Deckblatt';
$xarML_PHPBackend_entries['Attestation Submission'] = 'Beglaubigungsantrag';
?>