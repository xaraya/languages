<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Attestation-Service of the Basel Chamber of Commerce, Switzerland'] = 'Online-Beglaubigungsdienst der Handelskammer beider Basel, Schweiz';
$xarML_PHPBackend_entries['(Handelskammer beider Basel, Schweiz)'] = '(Basel Chamber of Commerce, Switzerland)';
$xarML_PHPBackend_entries['In the name and on behalf of our client and applicant mentioned below, identified by password and PIN, we ask you to see and complete the following PDF-documents with the Attestation and Stamp of the Basel Chamber of Commerce, Switzerland'] = 'Im Namen und Auftrag unseres Kunden, welcher mit Passwort und PIN identifiziert worden ist, bitten wir Sie den nachfolgenden Beglaubigungsantrag zu prüfen und mit dem Stempel der Handelskammer beider Basel, Schweiz zu versehen.';
?>