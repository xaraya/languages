<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Terms and Conditions / Disclaimer'] = 'Nutzungsbedingungen und Konditionen';
?>