<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['I agree to be bound by this website\'s'] = 'Ich stimme den Nutzungsbedingungen der Web-Site zu';
$xarML_PHPBackend_entries['Please agree to the terms'] = 'Bitte akzeptieren Sie die Nutzungsbedingungen';
$xarML_PHPBackend_entries['I agree to be bound by this website\'s '] = 'Ich erkläre mich einverstanden mit der Web-Site\'s';
$xarML_PHPBackend_entries['and'] = 'und';
?>