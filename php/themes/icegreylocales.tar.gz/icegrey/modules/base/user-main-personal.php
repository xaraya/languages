<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Personal Details'] = 'Persönliche Daten';
$xarML_PHPBackend_entries['You have no personal information stored.'] = 'Sie haben keine persönlichen Daten gespeichert.';
$xarML_PHPBackend_entries['to enter personal data.'] = 'um persönliche Daten einzugeben.';
$xarML_PHPBackend_entries['Date of Birth'] = 'Geburtsdatum';
$xarML_PHPBackend_entries['n/a'] = 'nicht verfügbar';
$xarML_PHPBackend_entries['Height'] = 'Grösse';
?>