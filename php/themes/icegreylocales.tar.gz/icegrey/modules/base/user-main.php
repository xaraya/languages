<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['My Help Data Overview'] = 'ice.todo Übersicht';
$xarML_PHPBackend_entries['Documents'] = 'Dokumente';
$xarML_PHPBackend_entries['Your Account'] = 'Ihr Konto';
$xarML_PHPBackend_entries['Member Profile'] = 'Benutzerprofil';
$xarML_PHPBackend_entries['Billing Information'] = 'Rechnungsinformation';
?>