<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['to add another bank.'] = 'um eine weitere Bank hinzuzufügen.';
$xarML_PHPBackend_entries['You have no financial information stored.'] = 'Sie haben keine Finanzdaten gespeichert.';
$xarML_PHPBackend_entries['Street Address'] = 'Strasse';
$xarML_PHPBackend_entries['Telephone'] = 'Telefon';
$xarML_PHPBackend_entries['Fax'] = 'Fax';
$xarML_PHPBackend_entries['Account Number'] = 'Kontonummer';
$xarML_PHPBackend_entries['No accounts listed.'] = 'Keine Konten aufgeführt.';
?>