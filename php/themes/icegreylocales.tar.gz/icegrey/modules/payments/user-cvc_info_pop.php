<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['3 Digit Card Security Code'] = '3 stelliger Sicherheitscode';
$xarML_PHPBackend_entries['For your safety and security, you are required to enter your card\'s security code. The security code is a 3-digit number printed on the back of your card. It appears after and to the right of your card number'] = 'Zu Ihrer Sicherheit, müssen Sie den Sicherheitskode der Karte eingeben. Der Sicherheitskode ist eine aufgedruckte 3-stellige Nummer auf der Rückseite Ihrer Karte.';
$xarML_PHPBackend_entries['Using American Express?'] = 'Verwenden Sie American Express?';
?>