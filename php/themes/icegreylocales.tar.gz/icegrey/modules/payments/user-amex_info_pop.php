<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['4 Digit Card Security Code'] = '4 stelliger Sicherheitscode';
$xarML_PHPBackend_entries['For your safety and security, you are required to enter your card\'s security code. The American Express security code is a 4-digit number printed on the front of your card. It appears after and to the right of your card number.'] = 'Zu Ihrer Sicherheit, müssen Sie den Sicherheitskode der Karte eingeben. Der American Express Sicherheitskode ist eine aufgedruckte 4-stellige Nummer auf Ihrer Karte.      ';
$xarML_PHPBackend_entries['Using Visa, MasterCard or Discover?'] = 'Verwenden Sie Visa, MasterCard oder Discovery?';
?>