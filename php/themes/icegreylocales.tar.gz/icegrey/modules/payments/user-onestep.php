<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Enter payment information'] = 'Bitte geben Sie die Zahlungsdaten ein';
$xarML_PHPBackend_entries['Where is my security code?'] = 'Wo ist mein Sicherheitscode?';
?>