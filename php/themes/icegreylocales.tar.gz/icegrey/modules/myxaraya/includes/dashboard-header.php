<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['\'links\''] = '\'Links\'';
$xarML_PHPBackend_entries['My Documents'] = 'Meine Dokumente';
$xarML_PHPBackend_entries['Weather'] = 'Wetter';
?>