<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Reminders'] = 'Benachrichtigungen';
$xarML_PHPBackend_entries['My Reminders'] = 'Meine Errinnerungen';
?>