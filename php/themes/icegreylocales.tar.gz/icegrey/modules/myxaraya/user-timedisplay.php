<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Change Time Settings'] = 'Zeit-Einstellungen ändern';
$xarML_PHPBackend_entries['(Set the time for locations of your choice)'] = '(Setzen Sie die Zeit für Orte Ihrer Wahl)';
$xarML_PHPBackend_entries['Times'] = 'Zeiten';
$xarML_PHPBackend_entries['Find a Place:'] = 'Suchen Sie einen Ort:';
$xarML_PHPBackend_entries[' Enter the name of a location and click "Find"'] = 'Geben Sie den Ortsnamen ein und klicken Sie auf "Suchen"';
?>