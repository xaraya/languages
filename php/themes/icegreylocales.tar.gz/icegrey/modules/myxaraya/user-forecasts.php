<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Weather Forecast'] = 'Wettervorhersage';
$xarML_PHPBackend_entries['Change Weather Forecast Settings'] = 'Vorhersageeinstellungen ändern';
$xarML_PHPBackend_entries['(Set the weather forecast for locations of your choice)'] = '(wählen Sie die Orte für die Vorhersagen)';
$xarML_PHPBackend_entries['Currently in #(1)'] = 'Währung in #(1)';
$xarML_PHPBackend_entries['Feels Like'] = 'Fühlt sich an wie';
$xarML_PHPBackend_entries['Today'] = 'Heute';
$xarML_PHPBackend_entries['Tonight'] = 'Heute Nacht';
$xarML_PHPBackend_entries['Daytime High'] = 'Tageshöchsttemperatur';
$xarML_PHPBackend_entries['Overnight Low'] = 'Nächtlicher Tiefstwert';
$xarML_PHPBackend_entries['Sunrise'] = 'Sonnenaufgang';
$xarML_PHPBackend_entries['Sunset'] = 'Sonnenuntergang';
$xarML_PHPBackend_entries['Visibility'] = 'Sicht';
$xarML_PHPBackend_entries['Dew Point'] = 'Taupunkt';
$xarML_PHPBackend_entries['Humidity'] = 'Luftfeuchtigkeit';
$xarML_PHPBackend_entries['Pressure'] = 'Luftdruck';
$xarML_PHPBackend_entries['Wind Gusts'] = 'Windböhen';
$xarML_PHPBackend_entries['As reported at #(1). Last Updated #(2)'] = 'Gemessen in #(1). Letzmals aktualisiert #(2)';
$xarML_PHPBackend_entries['Extended Forecast'] = 'Erweiterte Vorhersage';
$xarML_PHPBackend_entries['Precip. %'] = 'Niederschlag %';
$xarML_PHPBackend_entries['No locations have been set. To set locations please go'] = 'Es wurden noch keine Lokationen gesetzt. Bitte gehen Sie';
?>