<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Show the last '] = 'Die neuesten Anzeigen';
$xarML_PHPBackend_entries[' actions'] = 'Aktionen';
$xarML_PHPBackend_entries['Time'] = 'Zeit';
?>