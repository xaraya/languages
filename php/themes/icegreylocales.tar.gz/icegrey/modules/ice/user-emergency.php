<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Emergency Documents'] = 'Notfall-Dokumente';
$xarML_PHPBackend_entries['Document Name'] = 'Dokument-Name';
$xarML_PHPBackend_entries['No documents.'] = 'Keine Dokumente';
$xarML_PHPBackend_entries['Itinerary Information'] = 'Reiseprogramm';
$xarML_PHPBackend_entries['My last tracked locations'] = 'Meine letzten gespeicherten geografischen Positionen';
?>