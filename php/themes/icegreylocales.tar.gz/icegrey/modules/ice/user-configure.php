<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['\'My Accounts\''] = '\'Meine Konten\'';
$xarML_PHPBackend_entries['\'config\''] = '\'Konfiguration\'';
$xarML_PHPBackend_entries['Accounts'] = 'Konten';
$xarML_PHPBackend_entries['Account #$key#:'] = 'Konto #Skey#:';
?>