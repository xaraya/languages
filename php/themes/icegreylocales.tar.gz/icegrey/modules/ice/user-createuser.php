<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Create Your Emergency User'] = 'Notfall-Benutzer erstellen';
$xarML_PHPBackend_entries['Update Your Emergency User'] = 'Notfall-Benutzer aktualisieren';
$xarML_PHPBackend_entries['Register here an emergency user. Enter the name of the user in the name box. Enter the password for the emergency user and confirm the password. Click on the field "Active" to activate the emergency user. Click on "Update Emergency User" to process your input.'] = 'Erfassen Sie hier einen Notfallbenutzer. Geben Sie den Namen der Benutzerin bzw. des Benutzers im Feld ein. Geben Sie das Passwort für den Notfallbenutzer ein und bestätigen Sie das Passwort durch erneute Eingabe. Klicken Sie auf das Feld "aktiv" um den Notfallbenutzer freizuschalten. Klicken Sie auf OK um den Vorgang abzuschliessen.';
$xarML_PHPBackend_entries['Hand over this user name and password to a person of confidence to allow the access to the site "Emergency View". For this purpose we recommend to use the'] = 'Übergeben Sie diesen Benutzernamen und das Passwort an eine Vertrauensperson, um dieser den Zugang zur Seite "Notfall Ansicht"  zu ermöglichen. Wir empfehlen zu diesem Zweck den Notfallausweis (ice.card) zu benutzen.';
$xarML_PHPBackend_entries['Update Emergency User'] = 'Notfall-Plan aktualisieren';
?>