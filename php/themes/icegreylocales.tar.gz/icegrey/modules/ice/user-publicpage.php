<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Send the link to download the icetodo Emergency-Plan to a friend and help your friend to prepare a safe journey.'] = 'Senden Sie den Link des icetodo Notfall-Plans an einen Freund und verhelfen Sie ihm damit zu einer sicheren Reise.';
?>