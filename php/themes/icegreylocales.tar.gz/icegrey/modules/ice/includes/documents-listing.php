<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Show '] = 'Anzeigen';
$xarML_PHPBackend_entries[' items'] = 'Elemente';
$xarML_PHPBackend_entries['Add ##(1)'] = 'Hinzufügen ##(1)';
$xarML_PHPBackend_entries['Show details'] = 'Details anzeigen';
$xarML_PHPBackend_entries['Download the file'] = 'Datei herunterladen';
?>