<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Posted by: #(1) on #(2) #(3)'] = 'Von #(1) am #(2) #(3)';
$xarML_PHPBackend_entries['(#(1) Reads)'] = '(#(1) mal gelesen';
$xarML_PHPBackend_entries['Note :'] = 'Bemerkung :';
?>