<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['read'] = 'lesen';
$xarML_PHPBackend_entries['reads'] = 'Zugriffe';
$xarML_PHPBackend_entries['Keywords'] = 'Schlüsselwörter';
?>