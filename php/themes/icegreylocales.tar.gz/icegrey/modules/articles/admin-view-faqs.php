<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Manage Articles'] = 'Artikel verwalten';
$xarML_PHPBackend_entries['Language : #(1)'] = 'Sprache : #(1)';
$xarML_PHPBackend_entries['New Article'] = 'Neuer Artikel';
$xarML_PHPBackend_entries['Question'] = 'Frage';
$xarML_PHPBackend_entries['Options'] = 'Optionen';
$xarML_PHPBackend_entries['Change checked article status to'] = 'Status der markierten Artikel ändern auf';
$xarML_PHPBackend_entries['[Delete All]'] = '[Alle löschen]';
$xarML_PHPBackend_entries['Approved'] = 'Freigegeben';
$xarML_PHPBackend_entries['Frontpage'] = 'Erste Seite';
$xarML_PHPBackend_entries['Check All'] = 'Alle markieren';
$xarML_PHPBackend_entries['Uncheck All'] = 'Alle Markierungen entfernen';
?>