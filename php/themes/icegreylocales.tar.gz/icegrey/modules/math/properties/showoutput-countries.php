<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
?>