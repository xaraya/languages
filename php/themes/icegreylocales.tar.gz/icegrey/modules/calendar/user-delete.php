<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Delete Event'] = 'Ereignis löschen';
$xarML_PHPBackend_entries['Confirm Deleting This Event?'] = 'Löschung bestätigen?';
?>