<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Calendar Events'] = 'Kalender Ereignisse';
$xarML_PHPBackend_entries['Add A New Event'] = 'Neues Ereignis hinzufügen';
?>