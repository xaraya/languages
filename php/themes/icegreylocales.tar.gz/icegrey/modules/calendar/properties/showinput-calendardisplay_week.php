<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Previous Week'] = 'Vorhergehende Woche';
$xarML_PHPBackend_entries['Next Week'] = 'Nächste Woche';
?>