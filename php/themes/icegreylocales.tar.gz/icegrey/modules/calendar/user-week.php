<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Click '] = 'Klicken Sie';
$xarML_PHPBackend_entries[' to view your last tracked locations'] = 'um Ihre letzten gespeicherten geografischen Positionen anzuzeigen';
$xarML_PHPBackend_entries['Show the calendar in my Emergency View'] = 'Kalender in der Notfall-Ansicht anzeigen';
$xarML_PHPBackend_entries['\'week\''] = '\'Woche\'';
?>