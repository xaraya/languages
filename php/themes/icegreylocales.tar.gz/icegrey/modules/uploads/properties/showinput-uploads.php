<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Attach file(s) from source:'] = 'Dateien hinzufügen aus Quelle:';
$xarML_PHPBackend_entries['Trusted'] = 'Vertrauenswürdig';
$xarML_PHPBackend_entries['External'] = 'Extern';
$xarML_PHPBackend_entries['Stored'] = 'gespeichert';
$xarML_PHPBackend_entries['Reset'] = 'zurücksetzen';
$xarML_PHPBackend_entries['Currently stored: '] = 'Z.Z gespeichert';
$xarML_PHPBackend_entries['Allowed file types : #(1)'] = 'Erlaubte Dateitypen: #(1)';
?>