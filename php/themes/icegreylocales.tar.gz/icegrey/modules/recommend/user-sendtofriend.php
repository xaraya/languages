<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Recomend a Page'] = 'Empfehlen Sie eine Seite';
$xarML_PHPBackend_entries['Thank you for recommending the icetodo Emergency Plan.'] = 'Besten Dank, dass Sie icetodo Notfall-Plan weiterempfehlen';
$xarML_PHPBackend_entries['An email has been sent to your friend.'] = 'Ein Email wurde an Ihren Freund versendet.';
$xarML_PHPBackend_entries['Your Email Address'] = 'Ihre Email-Adresse';
$xarML_PHPBackend_entries['Your Friend\'s Name'] = 'Name Ihres Freundes';
$xarML_PHPBackend_entries['Your Friend\'s Email Address:'] = 'Email Adresse Ihres Freundes';
$xarML_PHPBackend_entries['Your Added Notes'] = 'Ihre hinzugefügte Bemerkungen';
?>