<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['No details available'] = 'Keine Details verfügbar';
$xarML_PHPBackend_entries['Coordinates:'] = 'Koordinaten:';
?>