<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['© Copyright 2008 icetodo Ltd. Liab. Co - All Rights Reserved'] = '© Copyright 2008 icetodo GmbH - Alle Rechte vorbehalten';
$xarML_PHPBackend_entries['Impressum'] = 'Impressum';
?>