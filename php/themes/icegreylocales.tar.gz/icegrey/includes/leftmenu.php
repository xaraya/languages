<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['Home'] = 'Home';
$xarML_PHPBackend_entries['Services'] = 'Dienstleistungen';
$xarML_PHPBackend_entries['Renew Subscription'] = 'Abonnement erneuern';
$xarML_PHPBackend_entries['Info Desk'] = 'Info Punkt';
$xarML_PHPBackend_entries['Travel Alerts'] = 'Reise Alerts';
$xarML_PHPBackend_entries['Contact'] = 'Kontakt';
$xarML_PHPBackend_entries['Resellers'] = 'Wiederverkäufer';
$xarML_PHPBackend_entries['Rapid Registration'] = 'Schnelle Registrierung';
$xarML_PHPBackend_entries['Testing'] = 'Testen';
$xarML_PHPBackend_entries['Site Processes'] = 'Site Prozesse';
?>