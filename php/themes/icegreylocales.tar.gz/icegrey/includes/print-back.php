<?php
global $xarML_PHPBackend_entries;
global $xarML_PHPBackend_keyEntries;
$xarML_PHPBackend_entries['true'] = 'wahr';
$xarML_PHPBackend_entries['Print'] = 'drucken';
$xarML_PHPBackend_entries['Back'] = 'zurück';
?>